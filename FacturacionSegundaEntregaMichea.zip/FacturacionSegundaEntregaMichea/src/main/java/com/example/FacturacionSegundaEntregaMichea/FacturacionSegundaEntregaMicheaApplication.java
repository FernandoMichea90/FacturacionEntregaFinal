package com.example.FacturacionSegundaEntregaMichea;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FacturacionSegundaEntregaMicheaApplication {

	public static void main(String[] args) {
		SpringApplication.run(FacturacionSegundaEntregaMicheaApplication.class, args);
	}

}


  