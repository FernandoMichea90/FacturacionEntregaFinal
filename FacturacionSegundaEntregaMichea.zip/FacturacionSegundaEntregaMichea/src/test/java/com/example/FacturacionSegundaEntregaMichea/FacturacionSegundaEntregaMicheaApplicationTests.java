package com.example.FacturacionSegundaEntregaMichea;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FacturacionSegundaEntregaMicheaApplicationTests {

	@Test
	void contextLoads() {
	}

}
